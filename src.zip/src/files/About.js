function About(){
    return(
        <>
        <div>
            about developers :)
        </div>
        </>
    )
}
export default About;