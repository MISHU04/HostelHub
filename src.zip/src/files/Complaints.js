import React from 'react'
// import Navbarr from '../components/Navbarr';
// import propTypes from 'prop-types'
import './Colors.css';

function Complaints(){
    return(
        <>
        {/* <Navbarr/> */}
        <header>
    <h2 className="logo" >
        <img src="logo.svg" className='img2'/>
    </h2>
    {/* <div className="logo"></div> */}
    {/* <nav className="navigation">
        <a href="#">home</a>
        <a href="#">about</a>
        <button className="btnLogin-popup">login</button>
    </nav> */}
</header>
<div className="wrapper">
    <div className="form-box login">
        <h2>What's Your Problem?</h2>
        <form action="#">
            <div className="input-box">
                <span className="icon"></span>
                <input type="text" required/>
                <label className='name'>Name</label>
            </div>
            <div className="input-box">
                <span className="icon"></span>
                <input type="number" required/>
                <label>Room Number</label>
            </div>
            <div className="input-box">
                <span className="icon"></span>
                <input type="number" required/>
                <label>Roll Number</label>
            </div>
            <div className="input-box">
                <span className="icon"></span>
                <input type="tel" name="phone" className='phone'  required />
                <label>Phone Number</label>
            </div>
            {/* <div className="issue">
                <label htmlFor='issue' className='headissue'>Issue Avenue </label>
                <select name="issue" className="avenue" required>
  <option value="">None</option>
  <option value="electrical">Electrical<option value="electric">av</option></option>
  <option value="plumber">Plumber</option>
  <option value="wifi">Wifi</option>
  <option value="repairing">Repairing</option>
    </select> */}
            <div className="issue">
                <span className="icon"></span>
                <input type="text" maxLength={40} required/>
                <label>Issue Avenue</label>
            </div>
                
    {/* <ul>
        <li>Electrical
            <ul>
            <li>bulb</li>
            <li>fan</li></ul>
        </li>
        <li>Plumber</li>
        <li>wifi</li>
        <li>Repairing</li>
    </ul> */}
            {/* </div> */}
            {/* <div className="remember-forget"><label><input type="checkbox"/>Remember Me</label>
            <a href="#">Forgot Password</a></div> */}
            <button type="submit" className="btn">Submit</button>
            {/* <div className="login-register">
                <p>Don't have an account?<a href="#" className="registre-link">Register</a></p>
            </div> */}
        </form>
    </div>
</div>
    </>
    )
}
export default Complaints;